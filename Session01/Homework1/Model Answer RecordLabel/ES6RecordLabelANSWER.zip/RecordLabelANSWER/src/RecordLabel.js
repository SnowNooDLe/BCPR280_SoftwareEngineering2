class RecordLabel  {
	constructor () {
		this.allMyReleases = []
	}

	addRelease (newStyle, newTitle, newFormat, newYearReleased) {
		var newRelease = new Release(newStyle, newTitle, newFormat, newYearReleased, this)
		this.allMyReleases.push(newRelease)
	}

	findRelease  (targetTitle) {
		let foundRelease = null;
		for (let aRelease of this.allMyReleases) {
			if (aRelease.title === targetTitle) {
				foundRelease = aRelease
				break
			}
		}
		return foundRelease
	}

	sortReleases () {
		this.allMyReleases.sort( function (a, b) {
			return a.title > b.title
			})
	}
	//------------------------------------------------------
	getReleases() {
		this.sortReleases();
		let out = ''
		for (let aRelease of this.allMyReleases){
			out += aRelease + '\n'
		}
		return out
	}
	
	getReleasesWithTwoTracks(){
		let out = ''
		this.sortReleases()
		for (let aRelease of this.allMyReleases){
			if (aRelease.hasTwoTracks() ){
				out += aRelease + '\n'
				out += aRelease.getTracks()
			}
		}
		return out
	}
}