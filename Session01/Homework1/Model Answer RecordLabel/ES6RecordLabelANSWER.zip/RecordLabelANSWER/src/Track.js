class Track {
	constructor (theRelease, newTitle, newGenre, newType, newArtist) {
		//-------------------------------------------------------
		this.myRelease = theRelease
		this.title = newTitle
		this.genre = newGenre
		this.type = newType
		this.artist = newArtist

	}
	
	toString(){
		return '   ' + this.title + ' ' + this.genre + ' ' + this.artist
	}
	
}