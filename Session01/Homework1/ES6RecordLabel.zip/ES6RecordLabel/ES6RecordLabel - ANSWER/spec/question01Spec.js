/*globals describe beforeEach Controller it expect Artist Album Track*/
describe("Question One", function () {
    describe("Draw a class diagram", function () {})
})