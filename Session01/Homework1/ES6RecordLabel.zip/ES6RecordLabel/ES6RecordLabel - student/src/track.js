class Track {
	constructor(theRelease, newTitle, newGenre, newType, newArtist) {
	
	}
}