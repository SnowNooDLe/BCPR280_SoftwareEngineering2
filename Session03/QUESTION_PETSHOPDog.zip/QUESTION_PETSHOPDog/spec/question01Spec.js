/*globals describe beforeEach Controller it expect Kennel DogOwner Dog*/
describe("Question One", function () {
    'use strict';
    describe("Draw a class diagram", function () {});
});